package com.rafiyad.teamcollab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamcollabApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeamcollabApplication.class, args);
	}

}
